package automata;

public class TraceItem {
  public AutomatonState as;
  public double t;
  public double totalT;
  
  public TraceItem(AutomatonState as, double t, double totalT) {
    this.as = as; this.t = t; this.totalT = totalT;
  }
  
  public String toString() { return "{" +as + ", " + ((int)(t*100))/100.0 + ", " +((int)(totalT*100))/100.0+  "}"; } 
}
