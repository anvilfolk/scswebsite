package automata;

public class Message implements Comparable<Message>{
  private String label;
  private Double time;
  private State payload;
  
  public Message(String label, State payload) { this.label = label; this.payload = payload; }

  public void setTime(double time) { this.time = time; }
  
  public String getLabel() { return label; }
  public State getPayload(){ return payload; }
  
  public int compareTo(Message other) {
    return time.compareTo(other.time);
  }
}
