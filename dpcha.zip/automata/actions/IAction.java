package automata.actions;

public interface IAction {
  static final int NEW_ACTION = 0;
  static final int DIE_ACTION = 1;
  static final int SEND_ACTION = 2;
  static final int RECEIVE_ACTION = 3;
  int getType();
}
