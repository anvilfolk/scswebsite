package automata.actions;

import automata.*;
import automata.functions.*;

public class SendAction implements IAction {
  
  private ISendFunction f;
  
  public SendAction(ISendFunction f){ this.f = f; }
  
  public String getChannel(State s){ return f.channel(s); }
  public Message produceMessage(State s){ return f.newMessage(s); }
  
  public int getType() { return IAction.SEND_ACTION; }
}
