package automata.actions;

public class DieAction implements IAction {
  public int getType() { return IAction.DIE_ACTION; }
}
