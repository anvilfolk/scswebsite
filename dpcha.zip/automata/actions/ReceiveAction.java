package automata.actions;

import automata.*;
import automata.functions.*;

public class ReceiveAction implements IAction {
  
  private IReceiveFunction f;
  
  public ReceiveAction(IReceiveFunction f){ this.f = f; }
  
  public String getChannel(State s){ return f.channel(s); }
  public State transition(State state, State payload){ return f.transition(state, payload); }
  
  public int getType() { return IAction.RECEIVE_ACTION; }
}
