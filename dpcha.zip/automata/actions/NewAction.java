package automata.actions;

import automata.*;
import automata.functions.*;

public class NewAction implements IAction {
  private INewFunction f;
  
  public NewAction(INewFunction f){ this.f = f; }
  
  public Element execute(State s){ return f.newElement(s); }
  
  public int getType() { return IAction.NEW_ACTION; }
}
