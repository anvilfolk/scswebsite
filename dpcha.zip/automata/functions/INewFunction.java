package automata.functions;

import automata.Element;
import automata.State;

public interface INewFunction {
  Element newElement(State s);
}
