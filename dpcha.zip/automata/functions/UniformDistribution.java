package automata.functions;

import automata.*;

public class UniformDistribution implements IContinuousDistribution {

  private double a, b;
  
  public UniformDistribution(double a, double b){ this.a = a; this.b = b; }
  
  public double draw(State s) { return RandGen.uniform(a, b); }
}
