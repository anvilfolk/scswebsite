package automata.functions;

import automata.*;

public interface IReceiveFunction {
  State transition(State state, State payload);
  String channel(State s);
}
