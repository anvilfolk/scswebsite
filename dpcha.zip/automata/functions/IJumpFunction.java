package automata.functions;

import automata.State;

public interface IJumpFunction {
  State transition(State s);
}
