package automata.functions;

import automata.State;

public interface IContinuousDistribution {
  double draw(State s);
}
