package automata.functions;

import automata.*;

public class GaussianDistribution implements IContinuousDistribution {
  protected double mean, stddev;
  
  public GaussianDistribution(double mean, double stddev){ this.mean = mean; this.stddev = stddev; }
  
  public double draw(State s) { return RandGen.gaussian(mean, stddev); }
}
