package automata.functions;

import automata.*;

public interface ISendFunction {
  Message newMessage(State s);
  String channel(State s);
}
