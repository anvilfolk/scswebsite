package automata.functions;

import automata.*;

public interface ITransitionDistribution {
  // Given a state, decide which edge ([0, n]) to transition through
  // or decide to do a continuous transition (-1)
  int draw(State s, MessageLayer ml);
}
