package automata.functions;

import automata.*;

public class ExponentialDistribution implements IContinuousDistribution {

  private double rate;
  
  public ExponentialDistribution(double rate){ this.rate = rate; }
  
  public double draw(State s) { return RandGen.exponential(rate); }
}
