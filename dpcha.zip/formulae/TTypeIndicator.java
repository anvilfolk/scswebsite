package formulae;

import java.util.*;

import automata.*;

public class TTypeIndicator implements ITerm {
  private String elemName;
  private int stateSpace;
  
  public TTypeIndicator(String elemName, int stateSpace) { this.elemName = elemName; this.stateSpace = stateSpace; }

  public double interpret(TraceItem s, Map<String, Element> sigma) {
    if(sigma.get(elemName).getState().getNumVars() == stateSpace)
      return 1;
    
    return 0;
  }

  public boolean closed(Set<String> names) { return true; }
}
