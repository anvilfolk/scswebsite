package formulae;

public class TAggProd extends TAgg {
  public TAggProd(String elemName, ITerm t){
    super(elemName, t);
  }

  public double op(double a1, double a2){ return a1 * a2; }
}
