package formulae;
import java.util.Map;
import java.util.Set;

import automata.Element;
import automata.Trace;

public class FFalse extends Formula {
  
  public boolean satisfied(Trace s, Map<String, Element> sigma) { return false; }

  public boolean closed(Set<String> names) { return true; }
  
  public double samplingBound(){ return 0; }
}