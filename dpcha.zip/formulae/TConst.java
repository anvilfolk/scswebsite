package formulae;

import java.util.*;

import automata.*;

public class TConst implements ITerm {
  private double c;
  
  public TConst(double c) { this.c = c; }

  public double interpret(TraceItem s, Map<String, Element> sigma) { return c; }

  public boolean closed(Set<String> names) { return true; }
}
