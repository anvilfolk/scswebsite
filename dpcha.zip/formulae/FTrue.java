package formulae;
import java.util.Map;
import java.util.Set;

import automata.Element;
import automata.Trace;

public class FTrue extends Formula {
  
  public boolean satisfied(Trace s, Map<String, Element> sigma) { return true; }

  public boolean closed(Set<String> names) { return true; }
  
  public double samplingBound(){ return 0; }
}