package formulae;

public class TAggSum extends TAgg {
  public TAggSum(String elemName, ITerm t){
    super(elemName, t);
  }

  public double op(double a1, double a2){ return a1 + a2; }
}
