package formulae;
import automata.*;

public interface IFormula {
  static double INDIFFERENCE_VALUE = 10e-5;
  
	boolean satisfied(Trace s);
	boolean closed();
	double samplingBound();
}
