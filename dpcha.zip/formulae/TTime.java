package formulae;

import java.util.*;

import automata.*;

public class TTime implements ITerm {
  
  public double interpret(TraceItem s, Map<String, Element> sigma) { return s.totalT; }

  public boolean closed(Set<String> names) { return true; }
}
