package formulae;

import java.util.*;

import automata.*;

public class TAbs implements ITerm {
  private ITerm t1;
  
  public TAbs(ITerm t1) { this.t1 = t1; }

  public double interpret(TraceItem s, Map<String, Element> sigma) {
    return Math.abs(t1.interpret(s, sigma));
  }

  public boolean closed(Set<String> names) { return true; }
}
