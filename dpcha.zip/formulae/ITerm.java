package formulae;

import java.util.*;

import automata.*;

public interface ITerm {
  double interpret(TraceItem s, Map<String, Element> sigma);
  boolean closed(Set<String> names);
}
