package modelchecking;

public class EstimationResult {
  public double t0;
  public double t1;
  public double p;
  public int n;
  public int nSat;
  
  public String toString() {
    return "["+t0+", "+t1+"] - " + p + " - "+nSat+"/"+n;
  }
}