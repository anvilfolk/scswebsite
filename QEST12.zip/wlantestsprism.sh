#!/bin/bash

files=("wlan0" "wlan1" "wlan2" "wlan3" "wlan4" "wlan5" "wlan6")


for i in "${files[@]}"
do
  echo $i
  (bash -c "time prism $i.nm wlan_collide.pctl" 2>&1)> $i\_prism\_results.txt
done
