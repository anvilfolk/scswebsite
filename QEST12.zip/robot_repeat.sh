#!/bin/bash

i="0"
while [ $i -lt $1 ]
do
./rungc.sh robot3.nm robot2.fm 20 2000 200 -DEBUG -H=0.3 -lastnsat=1000 -pathnsat=0 -lastsat=10000 -pathsat=10000 -reward=lastaction -update=compcount -IntervalEstimation -checkpoint >> robot_results/robot$i\_results.txt
i=$(( $i+1 ))
echo $i
done
