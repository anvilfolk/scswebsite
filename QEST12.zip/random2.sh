#!/bin/bash

thetas=("0.1" "0.2" "0.3" "0.4" "0.5" "0.6" "0.7" "0.8" "0.9")

i="0"
while [ $i -lt 5 ]
do
  java -cp bin RandomModel 1 8 20 5 > random/random$i\_var8.nm
  
  th="0"
  for theta in "${thetas[@]}"
  do
    rm random/random$i\_$th\_var8.txt
    j="0"
    while [ $j -lt 5 ]
    do
      #echo i $i j $j theta $theta
      ./run.sh random/random$i\_var8.nm random/random1_50.fm 20 2000 30 -MACHINE -PROFILE -theta=$theta >> random/random$i\_$th\_var8.txt
      j=$(( $j+1 ))
      echo -n +
    done
    echo Finished theta $theta
    th=$(( $th+1 ))
  done
  i=$(( $i+1 ))
  echo Finished test $i
done

echo
