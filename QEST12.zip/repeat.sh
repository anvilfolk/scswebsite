#!/bin/bash

echo $1

i="0"
while [ $i -lt $2 ]
do
./run.sh $1.nm $1.fm $3 $4 $5 | grep , >> $1_$6_results.txt
i=$(( $i+1 ))
echo -n $i\ 
done

echo