#!/bin/bash
rm tmpresults.txt

i="0"
while [ $i -lt $1 ]
do
(bash -c "time ./run.sh mutexbugged10.nm mutexbugged10.fm 3 2000 30" 2>&1) | grep -e ",\|real" >> tmpresults.txt
i=$(( $i+1 ))
echo $i
done

cat tmpresults.txt
