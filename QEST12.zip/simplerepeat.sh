#!/bin/bash
rm tmpresults.txt

i="0"
while [ $i -lt $1 ]
do
./run.sh mutexbugged10.nm mutexbugged10.fm 1000 30 | grep "," >> tmpresults.txt
i=$(( $i+1 ))
echo $i
done

cat tmpresults.txt