export DYLD_LIBRARY_PATH=/Users/jmartins/tools/prism-4.0.2-src/lib/
export LD_LIBRARY_PATH=$HOME/tools/prism-4.0.2-src/lib/
java -Xmx10000m -Xms10000m -verbose:gc -Xloggc:gc.log -XX:+UseParallelGC -XX:+UseParallelOldGC -Djava.library.path=$HOME/tools/prism-4.0.2-src/lib -cp .:./bin/:./scalabin/:$HOME/tools/scala-2.9.1.final/lib/scala-library.jar:$HOME/tools/prism-4.0.2-src/lib/colt.jar:$HOME/tools/lib/ssj.jar:$HOME/tools/lib/optimization.jar learn.LearnMDP $@
