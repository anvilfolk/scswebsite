#!/bin/bash

thetas=("0.1" "0.2" "0.3" "0.4" "0.5" "0.6" "0.7" "0.8" "0.9")

i="0"
while [ $i -lt 5 ]
do
  #java -cp bin RandomModel 1 7 20 5 > random/random$i.nm  
  rm random/random$i\_var8\_prism.txt
  (bash -c "time prism -mtbdd random/random$i\_var8.nm random/random_50.pctl" 2>&1) > random/random$i\_var8\_prism.txt
  i=$(( $i+1 ))
  echo Finished test $i
done

echo
