#!/bin/bash

files=("mutexbugged10" "mutexbugged15" "mutexbugged20" "mutexbugged25" "mutexbugged30" "mutexbugged35" "mutexbugged40" "mutexbugged50" "mutexbugged60" "mutexbugged100")

#echo Counting scheduler update.
#echo
#tar -xf countbin.tar.gz

#for i in "${files[@]}"
#do
#  ./repeat.sh $i 50 20 1500 20 count
#done

echo
echo Epsilon-greedy scheduler update.
tar -xf epsilonbin.tar.gz
echo

for i in "${files[@]}"
do
  ./repeat.sh $i 20 20 1500 20 epsilon
done
