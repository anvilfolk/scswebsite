#!/bin/bash

files=("firewire_dl_3_200" "firewire_dl_3_800" "firewire_dl_36_200" "firewire_dl_36_800")


for i in "${files[@]}"
do
  ./repeat.sh $i 50 20 1 1 nolearning
done
