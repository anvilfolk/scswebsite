#!/bin/bash

files1=("csma2_2" "csma2_4" "csma2_6")
files2=("csma3_2" "csma3_4" "csma3_6")
files3=("csma4_2" "csma4_4" "csma4_6")

for i in "${files1[@]}"
do
  (bash -c " prism -mtbdd -cuddmaxmem 4000000 $i.nm csma2.pctl" 2>&1) > $i\_prism\_results.txt
  echo $i
done


for i in "${files2[@]}"
do
  (bash -c " prism -mtbdd -cuddmaxmem 4000000 $i.nm csma3.pctl" 2>&1) > $i\_prism\_results.txt
  echo $i
done

for i in "${files3[@]}"
do
  (bash -c " prism -mtbdd -cuddmaxmem 4000000 $i.nm csma4.pctl" 2>&1) > $i\_prism\_results.txt
  echo $i
done
