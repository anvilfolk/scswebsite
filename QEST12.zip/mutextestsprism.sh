#!/bin/bash

files=("mutexbugged10" "mutexbugged15" "mutexbugged20" "mutexbugged25" "mutexbugged30" "mutexbugged35" "mutexbugged40" "mutexbugged50" "mutexbugged60" "mutexbugged100")

for i in "${files[@]}"
do
  echo $i
  prism -cuddmaxmem 52428800 -sbmax 100000000 $i.nm $i.pctl > $i_results_prism.txt 
done
