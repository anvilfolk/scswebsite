#!/bin/bash

prism -mtbdd tinyrobot.nm tinyrobot.pctl > robot_results/tiny_results.txt
prism -mtbdd smallrobot.nm smallrobot.pctl > robot_results/small_results.txt
prism -mtbdd mediumrobot.nm mediumrobot.pctl > robot_results/medium_results.txt
prism -mtbdd robot2.nm robot3.pctl > robot_results/regular_results.txt