#!/bin/bash

ntests="5"
nruns="10"

i="0"
while [ $i -lt $ntests ]
do
  j="0"
  while [ $j -lt $nruns ]
  do
    ./rungc.sh averagemodel.nm tinyrobot.fm 20 3500 200 -MACHINE -PROFILE -theta=0.99 -H=0.3 -lastnsat=1000 -pathnsat=0 -lastsat=10000 -pathsat=10000 -reward=lastaction -update=compcount -checkpoint >> robot_results/average_HT_0.99_extra_results.txt
    echo run $j
    j=$(( $j+1 ))
  done
i=$(( $i+1 ))
echo test $i
done

echo 