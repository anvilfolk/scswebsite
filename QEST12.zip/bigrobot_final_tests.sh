#!/bin/bash


thetas=("0.8" "0.85")

nruns="50"

i="0"
while [ $i -lt $nruns ]
do
  ./rungc.sh largemodel.nm robot2.fm 20 2000 200 -MACHINE -PROFILE -theta=0.9 -H=0.3 -lastnsat=1000 -pathnsat=0 -lastsat=10000 -pathsat=10000 -reward=lastaction -maxtraces=40000 -update=compcount -checkpoint >> robot_results/bigrobot_HT_0.9_results.txt
  i=$(( $i+1 ))
  echo $i
done



i="0"
while [ $i -lt $nruns ]
do
  for theta in "${thetas[@]}"
  do
    ./rungc.sh largemodel.nm.nm robot2.fm 20 2000 200 -MACHINE -PROFILE -theta=$theta -H=0.3 -lastnsat=1000 -pathnsat=0 -lastsat=10000 -pathsat=10000 -reward=lastaction -maxtraces=40000 -update=compcount -checkpoint >> robot_results/bigrobot_HT_$theta\_results.txt
    echo $theta
  done
  i=$(( $i+1 ))
  echo $i
done
