import os
import sys

filenames=("mutexbugged10_count_results.txt", "mutexbugged20_count_results.txt", "mutexbugged30_count_results.txt", "mutexbugged50_count_results.txt", "mutexbugged100_count_results.txt")

def main():

    for f in filenames:
        fi = open(f, "r")
        n = 0
        runtime = 0.0
        for line in fi:
            if n == 10:
                break
            n = n + 1
            tokens = line.rstrip("\n\r").split(" - ")
            runtime = runtime + float(tokens[4])

        print f + ", " + str(runtime)
        fi.close()

if __name__ == "__main__":
    main()
