#!/bin/bash

files1=("zeroconf_50000_1" "zeroconf_50000_2" "zeroconf_50000_1_false" 
"zeroconf_50000_2_false" )
files2=("zeroconf_50000_4_false")

#echo Counting scheduler update.
#echo
#tar -xf countbin.tar.gz

for i in "${files1[@]}"
do
  ./repeat.sh $i 50 20 2000 15 count
done

for i in "${files2[@]}"
do
  ./repeat.sh $i 50 20 5000 20 count
done
