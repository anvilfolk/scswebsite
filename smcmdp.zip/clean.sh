rm bin/*.class bin/smcmdp/*.class bin/modelchecking/*.class scalabin/smcmdp/*.class
