import os
import sys

thetas = (0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95)

def main():
    if(len(sys.argv) < 2):
        print "Usage: python data.py filename column"
        exit()

    if(not os.path.exists("./"+sys.argv[1] + "_HT_0.05.txt")):
        print sys.argv[1] + " does not exist."
        exit()

    if(not sys.argv[2].isdigit()):
        print sys.argv[2] + " is not an column index."
        exit()

    result = list()
    for theta in thetas:
        index = int(sys.argv[2])
        column = list();
        f = open(sys.argv[1] + "_HT_" + str(theta) + ".txt", 'r')
        for line in f:
            column.append(line.rstrip("\n\r").split(",")[index])
        result.append(sum(map(float,column)) / len(column))
        f.close()
        
    print '\t'.join(map(str,thetas))
    print '\t'.join(map(str,result))

if __name__ == "__main__":
    main()
