#!/bin/bash

echo Core test.
echo

n="31"
while [ $n -lt 41 ]
do
  echo -n $n\ 
  ./repeat.sh mutexbugged10 10 $n 1500 20 core$n
  n=$(( $n+1 ))
done

echo 
n="31"
while [ $n -lt 41 ]
do
  echo -n $n\ 
  ./repeat.sh mutexbugged30 10 $n 1500 20 core$n
  n=$(( $n+1 ))
done

echo
