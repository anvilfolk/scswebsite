#!/bin/bash

files1=("csma2_2" "csma2_4" "csma2_6" "csma3_2" "csma3_4" "csma3_6")
files2=("csma4_2" "csma4_4" "csma4_6")

echo Counting scheduler update.
echo
tar -xf countbin.tar.gz

for i in "${files1[@]}"
do
  ./repeat.sh $i 50 20 1500 20 count
done

for i in "${files2[@]}"
do
  ./repeat.sh $i 50 20 2500 20 count
done