#!/bin/bash
cat csma$1\_$2\_count_results.txt | sed 's/\[[0-9\.]*, [0-9\.]*\] - [0-9\.]* - [0-9]*\/[0-9]* - [0-9]* - //'
