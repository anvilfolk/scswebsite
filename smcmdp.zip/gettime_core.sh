#!/bin/bash
cat mutexbugged$1\_core$2\_results.txt | sed 's/\[[0-9\.]*, [0-9\.]*\] - [0-9\.]* - [0-9]*\/[0-9]* - [0-9]* - //'
