import os
import sys

toMatch = ("Number of AShr insts", "Number of Add insts", "Number of Alloca insts", "Number of BitCast insts", "Number of Br insts", "Number of Call insts", "Number of FAdd insts", "Number of FCmp insts", "Number of FDiv insts", "Number of FMul insts", "Number of FPToSI insts", "Number of FSub insts", "Number of GetElementPtr insts", "Number of ICmp insts", "Number of Load insts", "Number of Mul insts", "Number of Or insts", "Number of PHI insts", "Number of PtrToInt insts", "Number of Ret insts", "Number of SDiv insts", "Number of SExt insts", "Number of Select insts", "Number of Shl insts", "Number of SIToFP inst", "Number of SRem insts", "Number of Shl insts", "Number of Store insts", "Number of Sub insts", "Number of Switch insts", "Number of Trunc insts", "Number of UDiv insts", "Number of UIToFP insts", "Number of URem insts", "Number of Unreachable insts", "Number of Xor insts", "Number of ZExt insts", "Number of basic blocks", "Number of instructions (of all types)", "Number of memory instructions", "Number of non-external functions", "Number of And insts", "Number of LShr insts", "Number of ExtractValue insts", "Number of InsertValue insts", "Number of Invoke insts", "Number of LandingPad insts", "Number of Resume insts", "Number of FPExt insts", "Number of FPToUI insts", "Number of FPTrunc insts", "Number of FPExt insts")

result = [0] * len(toMatch)

fi = open(sys.argv[1], "r")

for line in fi:
  for i in range(len(toMatch)):
    if line.find(toMatch[i]) != -1:
      result[i] = int(line.strip().split()[0])
      break
    if i == len(toMatch)-1 and line.find("--") == -1 and line.find("..") == -1 and line.strip() != "":
      print >> sys.stderr, "No match :: \""+line.rstrip()+"\""
    
fi.close()

for i in result:
  print i