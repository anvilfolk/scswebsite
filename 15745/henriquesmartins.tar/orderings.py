# This file generates all orderings of the .pass files

passes = ("code-elim.pass", "code-loop.pass", "code-mod.pass", "code-mot.pass")

for i1 in passes:
  for i2 in passes:
    for i3 in passes:
      for i4 in passes:
        if(i1 != i2 and i1 != i3 and i1 != i4 and i2 != i3 and i2 != i4 and i3 != i4):
          print i1, i2, i3, i4
    