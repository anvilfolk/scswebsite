import os
import sys

fi = open(sys.argv[1], "r")

total = 0
for line in fi:
  total = total + float(line)

fi.close()

print total

#fo = open(sys.argv[1], "w")
#fo.write(str(total));
#fo.close()