import sys

flabels = open("labels2.csv", "r")
fpca = open("featuresPCA.csv", "r")

labels = flabels.readlines()
pca = fpca.readlines()

flabels.close()
fpca.close()

for i in range(len(labels)):
  labels[i] = labels[i].rstrip()

converted = []


for i in range(len(pca)):
  pcas = pca[i].rstrip().split(";")
  res = labels[i]
  for j in range(len(pcas)):
    res = res + " " + str(j+1) + ":" + pcas[j]
  converted.append(res)

toValidate = int(sys.argv[1])

val = converted[toValidate]
del converted[toValidate]

fwrite = open("test_data", "w")
fwrite.write(val + "\n")
fwrite.close()

fwrite = open("training_data", "w")
#print val
for i in converted:
  fwrite.write(i + "\n")
  #print i
  
fwrite.close()