import os
import sys


fi = open(sys.argv[1], "r")
lines = fi.readlines()
fi.close()

if len(lines) == 0:
  print 0
  print 0
  print 0
  exit()


maxDepth=0
totalLines=0
numLoops=len(lines) / 2

for i in range(numLoops):
  if maxDepth < int(lines[2*i]):
    maxDepth = int(lines[2*i])
  totalLines = totalLines + int(lines[2*i + 1])


print numLoops
print maxDepth
print totalLines / numLoops