import csv
import datetime
import json

# Race data is going to be a dictionary, with neighborhoods as keys, values as race data
race_data = {}
# Time data is an array of the # of arrests for each of 24 hours of the day.
time_data = [0] * 24

# Read and process all the data
def process_data():
  # Open csv file with data
  with open('arrest-data.csv', 'r') as csvFile:
    # Use a csv reader to make things easier!
    reader = csv.DictReader(csvFile)
    for row in reader:
      neighborhood = row['INCIDENTNEIGHBORHOOD']
      
      # Make sure the neighborhood exists in race_data
      if not neighborhood in race_data:
        race_data[neighborhood] = [0,0,0]

      # Add race data
      if row['RACE'] == 'W':
        race_data[neighborhood][0] += 1
      elif row['RACE'] == 'B':
        race_data[neighborhood][1] += 1
      else:
        race_data[neighborhood][2] += 1
        
      # Add time data
      t = datetime.datetime.strptime(row['ARRESTTIME'], '%Y-%m-%dT%H:%M:%S')
      time_data[t.hour] += 1

def save_data():
  with open('race_data.json', 'w') as writeFile:
    writeFile.write(json.dumps(race_data) + '\n')
  with open('time_data.json', 'w') as writeFile:
    writeFile.write(json.dumps(time_data) + '\n')

if __name__ == "__main__":
    process_data()
    save_data()












